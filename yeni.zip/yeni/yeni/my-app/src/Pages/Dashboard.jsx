import { useState, useEffect } from "react";
import StatsBoard from "../Components/StatsBoard";
import ProjectModal from "../Components/ProjectModal";
import {
  formatDuration,
  formatCurrency,
  formatDate,
} from "../Interfaces/utils";

const Dashboard = () => {
  const [studies, setStudies] = useState(() => {
    const saved = localStorage.getItem("studies");
    return saved ? JSON.parse(saved) : [];
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);

  useEffect(() => {
    localStorage.setItem("studies", JSON.stringify(studies));
  }, [studies]);

  const handleAddNew = () => {
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleEdit = (project) => {
    setEditingProject(project);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    setStudies(studies.filter((s) => s.id !== id));
  };

  const handleSave = (savedProject) => {
    if (editingProject) {
      setStudies(
        studies.map((s) => (s.id === savedProject.id ? savedProject : s)),
      );
    } else {
      setStudies([...studies, savedProject]);
    }
    setIsModalOpen(false);
  };

  return (
    <div
      className="container py-5"
      style={{ backgroundColor: "#f8f9fa", minHeight: "100vh" }}
    >
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bolder text-dark mb-0">Freelancer Paneli</h2>
          <p className="text-muted small">
            Projelerini ve kazancını kolayca takip et.
          </p>
        </div>
        <button
          className="btn rounded-pill px-4 shadow custom-btn"
          onClick={handleAddNew}
        >
          + Yeni Proje Ekle
        </button>
      </div>

      <StatsBoard studies={studies} />

      <div className="card border-0 shadow-sm rounded-4 overflow-hidden mt-4">
        <div className="card-body p-0">
          <div className="table-responsive">
            {/* 1. text-nowrap ekleyerek yazıların alt satıra inmesini engelledik */}
            <table className="table table-hover align-middle mb-0 text-nowrap">
              <thead className="table-light">
                <tr>
                  {/* Genişlik (width) ayarlarını sildik ki mobilde esnek olsun */}
                  <th className="py-3 text-start ps-4">Proje</th>
                  <th className="py-3 text-center">Süre</th>
                  <th className="py-3 text-center">Saatlik Ücret</th>
                  <th className="py-3 text-center">Tarih</th>
                  <th className="py-3 text-center">Kazanç</th>
                  <th className="py-3 text-center">İşlemler</th>
                </tr>
              </thead>
              <tbody className="border-top-0">
                {studies.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="py-5 text-center text-muted">
                      Henüz hiç kayıt girmediniz. Yeni bir proje ekleyerek
                      başlayın.
                    </td>
                  </tr>
                ) : (
                  studies.map((study) => {
                    const income = (study.duration / 60) * study.hourlyRate;
                    return (
                      <tr key={study.id}>
                        <td className="text-start ps-4 fw-medium text-dark">
                          {study.project}
                        </td>
                        <td className="text-center">
                          <span className="badge bg-light text-dark py-2 px-3">
                            {formatDuration(study.duration)}
                          </span>
                        </td>
                        <td className="text-center">
                          {formatCurrency(study.hourlyRate)}
                        </td>
                        <td className="text-center">
                          {formatDate(study.date)}
                        </td>
                        <td className="text-center fw-bold text-success">
                          {formatCurrency(income)}
                        </td>
                        {/* BURASI DEĞİŞTİ: Kazanç ile arasına mesafe koymak için ortaladık */}
                        <td className="text-center">
                          <div className="d-flex justify-content-center gap-2">
                            <button
                              className="btn btn-sm rounded-pill px-3 fw-medium transition-all"
                              style={{
                                backgroundColor: "#E0E7FF",
                                color: "#4F46E5",
                                border: "none",
                              }}
                              onClick={() => handleEdit(study)}
                            >
                              Düzenle
                            </button>
                            <button
                              className="btn btn-sm rounded-pill px-3 shadow-sm fw-medium transition-all"
                              style={{
                                backgroundColor: "#F43F5E",
                                color: "white",
                                border: "none",
                              }}
                              onClick={() => handleDelete(study.id)}
                            >
                              Sil
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <ProjectModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        editingProject={editingProject}
      />
    </div>
  );
};

export default Dashboard;
